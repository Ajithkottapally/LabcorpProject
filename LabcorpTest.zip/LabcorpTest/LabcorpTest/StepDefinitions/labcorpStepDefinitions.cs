using LabcorpTest.Pages;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using TechTalk.SpecFlow;

namespace LabcorpTest.StepDefinitions
{
    [Binding]

    public class LabCorpStepDefinitions
    {
        public HomePage homepage = new HomePage();

        [Given(@"user navigates to the labcorp website")]
        public void GivenUserNavigatesToTheLabcorpWebsite()
        {
            homepage.openUrl();
        }

        [When(@"user clicks on careers link and verifies the page is loaded")]
        public void WhenUserClicksOnCareersLinkAndVerifiesThePageIsLoaded()
        {
            homepage.clickCareers();

        }

        [Then(@"user search for position ""([^""]*)"" and opens it")]
        public void ThenUserSearchForAPositionAndOpensIt(String jobtitle)
        {
            homepage.searchposition(jobtitle);
        }

        [Then(@"user validates the job posting")]
        public void ThenUserValidatesTheJobPosting()
        {
            homepage.validatejobposting();
            
        }

        [Then(@"user clicks apply now and validates")]
        public void ThenUserClicksApplyNowAndValidates()
        {
            homepage.clickApplynow();
        }

        [Then(@"clicks on home link")]
        public void ThenClicksOnHomeLink()
        {
           homepage.clickhome();
        }
    }
}
