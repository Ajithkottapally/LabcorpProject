﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;

namespace LabcorpTest.pageElements
{
    public class HomePageElements
    {
      public  String  homelogo = "//*[@aria-label='Labcorp home logo']";
        public String careersLink = "Careers";
        public String jobSearchText = "(//*[@id='typehead'])[1]";
        public String search = "(//*[@type=\"submit\"])[1]";
        public String position = "//*[contains(@data-ph-at-job-title-text,'QA Test Automation')]";
        public String title = "//*[@class=\"job-title\"]";
        public String location = "//*[@class=\"au-target job-location\"]";
        public String jobID = "//*[@class=\"au-target jobId\"]";
        public String responsibilities = "//*[@class=\"jd-info au-target\"]//*[contains(text(),'Responsibilities')]";
        public String requirement = "//*[@class=\"jd-info au-target\"]//*[contains(text(),'5+ years of experience in QA')]";
        public String privacylink= "Privacy Statement";
        public String applyNow = "(//*[@ph-tevent=\"apply_click\"])[1]";
        public String home = "//*[@data-automation-id=\"navigationItem-Careers Home\"]";
    }
}
