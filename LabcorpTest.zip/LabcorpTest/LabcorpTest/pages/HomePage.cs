﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium.Support.UI;
using Selenium.DefaultWaitHelpers;
using LabcorpTest.pageElements;
using NUnit.Framework;

namespace LabcorpTest.Pages
{
    public class HomePage
               
    {
        public HomePageElements pageElements  = new HomePageElements();
       


        IWebDriver driver = new ChromeDriver();
        WebDriverWait wait;
       
        public void openUrl() {
            this.wait = new WebDriverWait(driver, TimeSpan.FromSeconds(30));
            driver.Manage().Window.Maximize();
            driver.Navigate().GoToUrl("https://www.labcorp.com/");
            //explicit wait till the logo is displayed
            wait.Until(ExpectedConditionsSearchContext.PresenceOfAllElementsLocatedBy(By.XPath(pageElements.homelogo)));        
            String currentTitle = driver.Title;
            if (currentTitle == "Labcorp | Global Life Sciences Leader in Diagnostics & Drug Development")
            {
                Console.WriteLine("Page Loaded successfully");
            }
            else
            { 
                Console.WriteLine("Expceted: X ,is not equal to Actual result || Actual Result: "+ $"{currentTitle}");   
            }
        }
        public void clickCareers() 
        {
            try {
                wait.Until(ExpectedConditionsSearchContext.ElementExists(By.LinkText(pageElements.careersLink)));
                driver.FindElement(By.LinkText(pageElements.careersLink)).Click();
                driver.SwitchTo().Window(driver.WindowHandles.Last());
                wait.Until(ExpectedConditionsSearchContext.PresenceOfAllElementsLocatedBy(By.XPath(pageElements.jobSearchText)));
                String currentTitle = driver.Title;
                String ExpectedTitle = "Careers at Labcorp | Join The Pursuit";
                Assert.IsTrue(currentTitle == ExpectedTitle);
            }
            catch (NoSuchElementException e) {
                Console.WriteLine(e.Message);
            }
        }

        public void searchposition(String jobtitle) { 
            driver.FindElement(By.XPath(pageElements.jobSearchText)).SendKeys(jobtitle);
            driver.FindElement(By.XPath(pageElements.search)).Click();
            // Open the position 
             
         //   if (verify(pageElements.position) == true)
           if(driver.FindElement(By.XPath(pageElements.position)).Displayed == true) 
           
            {
                driver.FindElement(By.XPath(pageElements.position)).Click();
            }
        }

        public void validatejobposting() {
            try {
                if (driver.FindElement(By.XPath(pageElements.title)).Displayed == true) 
                {
                 //  Thread.Sleep(500);
                    var Actual = driver.FindElement(By.XPath(pageElements.title)).Text;
                    Assert.AreEqual(Actual, "QA Test Automation Developer");
                    var Actual_location = driver.FindElement(By.XPath(pageElements.location)).Text;
                    Assert.IsTrue(Actual_location.Contains("United States of America"));
                    var Actual_jobID = driver.FindElement(By.XPath(pageElements.jobID)).Text;
                    Console.WriteLine("Actual_jobID: " + Actual_jobID);
                    Assert.AreEqual(Actual_jobID, "Job Id : 21-90223_RM"); 
                    var Actual_responsibility = driver.FindElement(By.XPath(pageElements.responsibilities)).Text;
                    Assert.AreEqual(Actual_responsibility, "Responsibilities:");
                    var Actual_requirement = driver.FindElement(By.XPath(pageElements.requirement)).Text;
                    Assert.AreEqual(Actual_requirement, "5+ years of experience in QA automation development and scripting.");
                   
                }
                else {
                    Console.WriteLine("Page title not found");
                        }
            } catch (NoSuchElementException e)
            {

            }
        }

        public void clickApplynow() {
            try { 
                    driver.FindElement(By.XPath(pageElements.applyNow)).Click();
                    driver.SwitchTo().Window(driver.WindowHandles.Last());
                    wait.Until(ExpectedConditionsSearchContext.PresenceOfAllElementsLocatedBy(By.XPath(pageElements.home)));
                    String currentTitle = driver.Title;
                    String ExpectedTitle = "Workday";
                    Assert.IsTrue(currentTitle == ExpectedTitle);

            } catch (NoSuchElementException e)
            {
                System.Console.WriteLine(e.Message);
            }
        }

        public void clickhome() {

            try
            {
               driver.FindElement(By.XPath(pageElements.home)).Click();
                driver.Quit();

            }
            catch (NoSuchElementException e)
            {
                System.Console.WriteLine(e.Message);
            }
        }
    }
}
